package com.digitalbanking.web;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.digitalbanking.model.EmailRequest;
import com.digitalbanking.model.EmailResponse;
import com.digitalbanking.service.EmailService;

import freemarker.template.TemplateException;


@RestController
@RequestMapping("/digitalbanking/email")
public class EmailController {
	@Value("$username")
	private String username;
	@Value("$password")
	private String password;
	@Autowired
	private EmailService service;
	
	@PostMapping("/sendEmail")
	public EmailResponse sendEmail(@RequestBody EmailRequest request) throws IOException, TemplateException {
		Map<String, Object> model = new HashMap<>();
		model.put("Name", request.getName());
		model.put("Location", "Bangalore,India");
		model.put("OTP","12345");
		return service.sendEmailWithOTP(request, model);

	}
}
