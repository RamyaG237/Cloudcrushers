package com.digitalbanking.web;

import javax.ws.rs.QueryParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.digitalbanking.model.UploadFileResponse;
import com.digitalbanking.service.FileUploadService;

import io.swagger.annotations.Api;

@RestController
@CrossOrigin(origins="*")
@RequestMapping("/digitalbanking/fileupload")
@Api(value="sample", description="FileUpload Controller")
public class FileUploadController {
	
	@Autowired
	FileUploadService uploadService;
	
	@PostMapping("/uploadFile")
    public ResponseEntity<UploadFileResponse> uploadFile(@RequestParam("file") MultipartFile file,
    													 @QueryParam("fileType") String fileType,
    													 @QueryParam("id") Long id)  
	{		
		UploadFileResponse response = uploadService.getFileUploaded(file, fileType, id);
        return new ResponseEntity<UploadFileResponse>(response, HttpStatus.OK);
	}
	
	/*@PostMapping("/uploadMultipleFiles")
    public ResponseEntity<List<UploadFileResponse>> uploadMultipleFiles(@RequestParam("files") List<MultipartFile> files) {
		
		List<UploadFileResponse> listOfFiles = uploadService.getMultipleFilesUploaded(files);
        return new ResponseEntity<List<UploadFileResponse>>(listOfFiles, HttpStatus.OK);
       
    }*/
	
}
