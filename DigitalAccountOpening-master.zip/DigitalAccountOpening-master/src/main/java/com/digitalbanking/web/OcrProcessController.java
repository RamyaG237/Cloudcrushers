package com.digitalbanking.web;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.io.File;
import java.io.FilenameFilter;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.digitalbanking.model.OcrRequest;
import com.digitalbanking.model.OcrResponse;
import com.digitalbanking.service.FileUploadService;
import com.digitalbanking.service.OcrImplService;
import com.digitalbanking.service.RegistrationService;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.swagger.annotations.Info;
import io.swagger.annotations.SwaggerDefinition;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(value = "/digitalbanking/validateOCR")
@SwaggerDefinition(info=@Info(description="OCR data extraction", title = "OCR", version = "1.0"))
public class OcrProcessController {

	private static Logger logger = LogManager.getLogger(OcrProcessController.class);
	final ObjectMapper mapper = new ObjectMapper();

	@Autowired
	OcrImplService ocrImplService;
	
	@Autowired
	RegistrationService regService;
		
	/**
	 * This controller is written for OCR data extraction
	 * @param jsonBody
	 * @return
	 * @throws Exception
	 */
	@GetMapping(value = "/{id}/KYC", produces = APPLICATION_JSON_VALUE)
	public @ResponseBody OcrResponse getKYC(@PathVariable Long id) throws Exception {
		
		final OcrRequest ocrRequest = new OcrRequest(regService.getToken(id), "jpg");

		logger.info(">>>>>> ocrDataExtraction process begins  :: ", ocrRequest.getToken());

		//Calling OCR implementation service
		return ocrImplService.performOCR(ocrRequest);

	}

}
