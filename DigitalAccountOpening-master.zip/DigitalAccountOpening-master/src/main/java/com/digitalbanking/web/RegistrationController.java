package com.digitalbanking.web;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.digitalbanking.exception.RecordNotFoundException;
import com.digitalbanking.model.RegistrationEntity;
import com.digitalbanking.model.RegistrationRequest;
import com.digitalbanking.service.RegistrationService;

import freemarker.template.TemplateException;
 
@RestController
@RequestMapping("/digitalbanking/registrations")
public class RegistrationController
{
    @Autowired
    RegistrationService service;
 
    @GetMapping("/getRegistrations")
    public ResponseEntity<List<RegistrationEntity>> getAllRegistrations() {
        List<RegistrationEntity> list = service.getAllRegistrations();
 
        return new ResponseEntity<List<RegistrationEntity>>(list, new HttpHeaders(), HttpStatus.OK);
    }
 
    @GetMapping("/getRegistrations/{id}")
    public ResponseEntity<RegistrationEntity> getRegistrationById(@PathVariable("id") Long id)
                                                    throws RecordNotFoundException {
        RegistrationEntity entity = service.getRegistrationById(id);
 
        return new ResponseEntity<RegistrationEntity>(entity, new HttpHeaders(), HttpStatus.OK);
    }
 
    //NotUsed
    /*@PostMapping
    public ResponseEntity<RegistrationEntity> createOrUpdateRegistration(RegistrationEntity Registration)
                                                    throws RecordNotFoundException, IOException, TemplateException {
        RegistrationEntity updated = service.createOrUpdateRegistration(Registration);
        return new ResponseEntity<RegistrationEntity>(updated, new HttpHeaders(), HttpStatus.OK);
    }*/
    
    @PostMapping("/registerUser")
    public ResponseEntity<RegistrationEntity> createRegistration(@RequestBody RegistrationRequest request)
                                                    throws IOException, TemplateException {
    	RegistrationEntity createUser = service.createRegistration(request);
        return new ResponseEntity<RegistrationEntity>(createUser, new HttpHeaders(), HttpStatus.CREATED);
    }
    
    //This API is not used currently and not tested.It may need some changes. 
    @PostMapping("/updateRegisteredUser")
    public ResponseEntity<RegistrationEntity> updateRegistration(RegistrationEntity Registration, @PathVariable("id") Long id ) 
    						throws RecordNotFoundException, IOException, TemplateException
    {
        RegistrationEntity updateUser = service.updateRegistration(Registration, id);
        return new ResponseEntity<RegistrationEntity>(updateUser, new HttpHeaders(), HttpStatus.CREATED);
    }
 
    @DeleteMapping("/deleteRegistration/{id}")
    public HttpStatus deleteRegistrationById(@PathVariable("id") Long id)
                                                    throws RecordNotFoundException {
        service.deleteRegistrationById(id);
        return HttpStatus.FORBIDDEN;
    }
    
    @GetMapping(value = "/{id}/refreshOTP")
    public String resend(@PathVariable final Long id) throws RecordNotFoundException {
    	return service.resendOTP(id);
    }
    
    @GetMapping(value = "/{id}/getOTP")
    public String OTP(@PathVariable final Long id) throws RecordNotFoundException {
    	return service.getOTP(id);
    }
    
	@PostMapping(value = "/{id}/validateOTP") 
	public boolean validateOTP(@PathVariable final Long id, @RequestBody String OTP) throws RecordNotFoundException {
		String sourceOTP = service.getOTP(id);
		return sourceOTP.equals(OTP);
	}
 
	@GetMapping(value = "/{id}/getToken")
    public String getTokenById(@PathVariable final Long id) /*throws RecordNotFoundException*/ {
    	return service.getToken(id);
    }
	
	@GetMapping(value = "/id/{id}/getStatusById")
    public String statusById(@PathVariable final Long id) throws RecordNotFoundException {
    	return service.getStatusById(id);
    }
	
	@GetMapping(value = "/token/{token}/getStatusByToken")
    public String statusByToken(@PathVariable final String token) throws RecordNotFoundException {
    	return service.getStatusByToken(token);
    }
	
	@PatchMapping("/{id}/updateStatus/{status}")
    public String updateStatus(@PathVariable Long id, @PathVariable String status){
    	return service.updateStatus(id, status).getStatus();
    }
	
	@PatchMapping("/{id}/confirmRegistration")
    public String confirmRegistration(@PathVariable Long id) {
    	return service.confirmRegistration(id, "Submitted");
    }
	
}