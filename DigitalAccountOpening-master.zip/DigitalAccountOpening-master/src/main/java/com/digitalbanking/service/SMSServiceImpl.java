package com.digitalbanking.service;

import org.springframework.stereotype.Service;

import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
@Service
public class SMSServiceImpl implements SMSService{

	public static final String ACCOUNT_SID = "your twilio sid";
	public static final String AUTH_TOKEN = "your twilio auth token";

	@Override
	public Message sendSMS(String otp,String phone) {
		Twilio.init(ACCOUNT_SID, AUTH_TOKEN);
		Message message = Message.creator(
				new com.twilio.type.PhoneNumber(phone),
				new com.twilio.type.PhoneNumber("your twilio phone number"),
				otp)
				.create();

		return message;
	}
}
