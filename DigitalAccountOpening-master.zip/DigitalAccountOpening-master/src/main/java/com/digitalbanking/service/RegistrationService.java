package com.digitalbanking.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.digitalbanking.exception.RecordNotFoundException;
import com.digitalbanking.model.EmailRequest;
import com.digitalbanking.model.RegistrationEntity;
import com.digitalbanking.model.RegistrationRequest;
import com.digitalbanking.repository.RegistrationRepository;
import com.twilio.rest.api.v2010.account.Message;

import freemarker.template.TemplateException;
 
@Service
public class RegistrationService {
     
    @Autowired
    RegistrationRepository repository;
    @Autowired
    EmailService emailService;
    @Autowired
    SMSService smsService;
    
	@Value("$username")
	private String username;
	
	/**
	 *  Get all the registrations done from the repository
	 */
    public List<RegistrationEntity> getAllRegistrations()
    {
        List<RegistrationEntity> RegistrationList = repository.findAll();
         
        if(RegistrationList.size() > 0) {
            return RegistrationList;
        } else {
            return new ArrayList<RegistrationEntity>();
        }
    }
     
    /**
     * Get one particular registration from DB for a particular user
     * @param id - user id generated during the registration
     */
    public RegistrationEntity getRegistrationById(Long id) throws RecordNotFoundException
    {
        Optional<RegistrationEntity> Registration = repository.findById(id);
         
        if(Registration.isPresent()) {
            return Registration.get();
        } else {
            throw new RecordNotFoundException("No Registration record exist for given id");
        }
    }
     
    /* Not Used
    public RegistrationEntity createOrUpdateRegistration(RegistrationEntity entity) throws RecordNotFoundException, IOException, TemplateException
    {
        Optional<RegistrationEntity> Registration = repository.findById(entity.getId());
        EmailRequest request=new EmailRequest();
        if(Registration.isPresent())
        {
            RegistrationEntity newEntity = Registration.get();
            newEntity.setEmail(entity.getEmail());
            newEntity.setFirstName(entity.getFirstName());
            newEntity.setLastName(entity.getLastName());
            newEntity.setPhone(entity.getPhone());
            newEntity.setGender(entity.getGender());
            //newEntity.setAddress(entity.getAddress());
            newEntity.setOtp(generateOTP());
            newEntity.setStatus(entity.getStatus());
            newEntity.setToken(getAlphaNumericString(8));
            request.setOtp(entity.getOtp());
        	request.setFrom(username);
        	request.setTo(entity.getEmail());
        	request.setSubject("OTP: "+entity.getOtp());
        	sendEmailWithOTP(request);	//sendSMS(entity.getOtp(),entity.getPhone());
            newEntity = repository.save(newEntity);
            return newEntity;
        } else {
        	entity.setOtp(generateOTP());
        	entity = repository.save(entity);
            return entity;
        }
    }*/
    
    /**
     * Register a user to open the digital account. 
     * @Request certain details of the user
     * @Response user data is saved in DB with a auto generated id along with OTP, token and status
     * OTP and token are also auto generated and passed for further use 
     * @status is saved as OPEN
     * Email is sent to the registered mail id with the OTP details
     * @throws RecordNotFoundException, IOException, TemplateException
     */
    public RegistrationEntity createRegistration(RegistrationRequest request) throws RecordNotFoundException, IOException, TemplateException
    {
    	RegistrationEntity entity = new RegistrationEntity();
    	EmailRequest emailEntity=new EmailRequest();
           	
    	// Save the values in DB
    	entity.setFirstName(request.getFirstName());
    	entity.setLastName(request.getLastName());
    	entity.setGender(request.getGender());
    	entity.setDob(request.getDob());
    	entity.setPhone(request.getPhone());
    	entity.setEmail(request.getEmail());
    	entity.setLine1(request.getLine1());
    	entity.setLine2(request.getLine2());
    	entity.setCity(request.getCity());
    	entity.setState(request.getState());
    	entity.setZip(request.getZip());
    	entity.setOtp(generateOTP());
    	entity.setToken(getAlphaNumericString(8));
    	entity.setStatus("OPEN");
    	entity = repository.save(entity);
    	
    	/*  This is commented due to environment limitations, but business
			functionality is working*/
    	
    	/*emailEntity.setOtp(entity.getOtp());
    	emailEntity.setName(entity.getFirstName());
    	emailEntity.setFrom(username);
    	emailEntity.setTo(entity.getEmail());
    	emailEntity.setSubject("View: Account update for your Bank A/C");
    	sendEmailWithOTP(emailEntity); */
    	//sendSMS(entity.getOtp(),entity.getPhone());
    	
        return entity;
    }
    
    /**
     * TODO
     * If the KYC data does not match then user has to update the registered data.
     * New OTP for validation will be sent to registered mail id
     */
    
    public RegistrationEntity updateRegistration(RegistrationEntity entity, Long id) 
    							throws RecordNotFoundException, IOException, TemplateException
    {
   	
    	RegistrationEntity newEntity = new RegistrationEntity();
    	EmailRequest emailEntity=new EmailRequest();
    	
    	Optional<RegistrationEntity> Registration = repository.findById(id);
        if(Registration.isPresent())
        {
            newEntity = Registration.get();
            newEntity.setEmail(entity.getEmail());
            newEntity.setFirstName(entity.getFirstName());
            newEntity.setLastName(entity.getLastName());
            newEntity.setPhone(entity.getPhone());
            newEntity.setGender(entity.getGender());
            newEntity.setDob(entity.getDob());
            newEntity.setLine1(entity.getLine1());
            newEntity.setLine2(entity.getLine2());
            newEntity.setCity(entity.getCity());
            newEntity.setState(entity.getState());
            newEntity.setZip(entity.getZip());
            newEntity.setOtp(generateOTP());
            newEntity.setStatus(entity.getStatus());
            newEntity.setToken(getAlphaNumericString(8));
            
        	//sendSMS(entity.getOtp(),entity.getPhone());
            emailEntity.setOtp(entity.getOtp());
        	emailEntity.setName(entity.getFirstName());
        	emailEntity.setFrom(username);
        	emailEntity.setTo(entity.getEmail());
        	emailEntity.setSubject("View: Account update for your Bank A/C");
        	sendEmailWithOTP(emailEntity); 
                  
        }else {
            throw new RecordNotFoundException("No Registration record exist for given id");
        }
        newEntity = repository.save(newEntity);     
        return newEntity;   
    }
     
    /**
     * Send email to registered mail Id with the generated OTP
     */
    private void sendEmailWithOTP(EmailRequest otpRequest) throws IOException, TemplateException {
    	Map<String, Object> model = new HashMap<>();
		model.put("Name", otpRequest.getName());
		model.put("OTP", otpRequest.getOtp());
		model.put("Location", "Bangalore,India");
    	emailService.sendEmailWithOTP(otpRequest,model);
	}
    
    /**
     *  TODO
     */
    public Message sendSMS(String otp,String phone) {
		return smsService.sendSMS(otp,phone);
	}

    /**
     * Delete a registered user from DB using the ID
     * @param id
     * @throws RecordNotFoundException
     */
	public void deleteRegistrationById(Long id) throws RecordNotFoundException
    {
        Optional<RegistrationEntity> Registration = repository.findById(id);
         
        if(Registration.isPresent())
        {
            repository.deleteById(id);
        } else {
            throw new RecordNotFoundException("No Registration record exist for given id");
        }
    }
	/**
     * Resend OTP incase user does not receive the same.
     * Currently this function is not getting used
     * @param id
     * @throws RecordNotFoundException
     */
    
    public String resendOTP(Long id) throws RecordNotFoundException
    {
        Optional<RegistrationEntity> Registration = repository.findById(id);
         
        if(Registration.isPresent())
        {
    	   RegistrationEntity entity = Registration.get();
    	   entity.setOtp(generateOTP());
    	   repository.save(entity);
           return entity.getOtp();
        } else {
            throw new RecordNotFoundException("No Registration record exist for given id");
        }
    }
    
    /**
     * To get the generated OTP using registered ID
     */
    
    public String getOTP(Long id) throws RecordNotFoundException
    {
        Optional<RegistrationEntity> Registration = repository.findById(id);
         
        if(Registration.isPresent())
        {
           return Registration.get().getOtp();
        } else {
            throw new RecordNotFoundException("No Registration record exist for given id");
        }
    }
    
    /**
     * GET the token using id of a registered user
     */
    public String getToken(Long id) /*throws RecordNotFoundException*/
    {
        Optional<RegistrationEntity> Registration = repository.findById(id);
         
        if(Registration.isPresent())
        {
           return Registration.get().getToken();
        } else {      	
            throw new RecordNotFoundException("No Registration record exist for given id");
        }
    }
    
    /**
     * get status of a registered user using Id 
     */
    public String getStatusById(Long id) throws RecordNotFoundException
    {
        Optional<RegistrationEntity> Registration = repository.findById(id);
         
        if(Registration.isPresent())
        {
           return Registration.get().getStatus();
        } else {
            throw new RecordNotFoundException("No Registration record exist for given id");
        }
    }
    
    /**
     * get status of a registered user by using the token
     */
    public String getStatusByToken(String token) throws RecordNotFoundException
    {
        Optional<RegistrationEntity> Registration = repository.findByToken(token);
         
        if(Registration.isPresent())
        {
           return Registration.get().getStatus();
        } else {
            throw new RecordNotFoundException("No Registration record exist for given id");
        }
    }
    
    /**
     * Update status of a user once the registration is successful
     */
    public RegistrationEntity updateStatus(Long Id, String status ) {
    	
    	Optional<RegistrationEntity> registration = repository.findById(Id);
    	RegistrationEntity entityStatus = new RegistrationEntity();
    	if(registration.isPresent()) {
    		entityStatus = registration.get();
    		entityStatus.setStatus(status);
    	}else {
    		throw new RecordNotFoundException("No Registration record exist for given id");
    	}
    	
    	return repository.save(entityStatus);
    	
    }
    
    /**
     * Confirm the registration and update the status in Db
     * Send email with the acknowledgement # to the user
     */
    
    public String confirmRegistration(Long Id, String status ) {
    	
    	Optional<RegistrationEntity> registration = repository.findById(Id);
    	String updatedStatus = null;
    	
    	if(registration.isPresent()) {
    		updatedStatus = updateStatus(Id,status).getStatus();
	    	
    		/*  This is commented due to environment limitations, but business
    			functionality is working*/
    		
	    	/*EmailRequest emailEntity=new EmailRequest();
	    	emailEntity.setName(registration.get().getFirstName());
	    	emailEntity.setFrom(username);
	    	emailEntity.setTo(registration.get().getEmail());
	    	emailEntity.setToken(registration.get().getToken());
	    	emailEntity.setSubject("View: Account update for your Bank A/C");
			try {
				sendEmailWithToken(emailEntity);
			} catch (IOException e) {
				System.out.println(e.getCause());
			} catch (TemplateException e) {
				System.out.println(e.getCause());
			}*/
    	}else {
    		throw new RecordNotFoundException("No Registration record exist for given id");
    	}
	        
		return updatedStatus;
    }
    
    /**
     * Send email to registered mail Id with the generated Token
     */
    
    private void sendEmailWithToken(EmailRequest tokenEntity) throws IOException, TemplateException {
    	Map<String, Object> model = new HashMap<>();
		model.put("Name", tokenEntity.getName());
		model.put("TOKEN", tokenEntity.getToken());
		model.put("Location", "Bangalore,India");
    	emailService.sendEmailWithToken(tokenEntity,model);
	}
    /**
     * Generate OTP
     */

	public String generateOTP() {
       Random random = new Random();
 	   return ""+(100000 + random.nextInt(900000));
 	}
	/**
	 * 
	 * The method to generate Token
	 * 
	 * @param  any number
	 * @return Token
	 */
    public static String getAlphaNumericString(int n) 
    { 
  
        // chose a Character random from this String 
        String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                                    + "0123456789"
                                    + "abcdefghijklmnopqrstuvxyz"; 
  
        // create StringBuffer size of AlphaNumericString 
        StringBuilder sb = new StringBuilder(n); 
  
        for (int i = 0; i < n; i++) { 
  
            // generate a random number between 
            // 0 to AlphaNumericString variable length 
            int index 
                = (int)(AlphaNumericString.length() 
                        * Math.random()); 
  
            // add Character one by one in end of sb 
            sb.append(AlphaNumericString 
                          .charAt(index)); 
        } 
  
        return sb.toString(); 
    } 
}