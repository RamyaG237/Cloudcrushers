package com.digitalbanking.service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Map;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.digitalbanking.model.EmailRequest;
import com.digitalbanking.model.EmailResponse;

import freemarker.template.Configuration;
import freemarker.template.TemplateException;


@Service
public class EmailService {
	
	@Autowired
	private JavaMailSender sender;
	
	@Autowired
	private Configuration config;
	
	public EmailResponse sendEmailWithOTP(EmailRequest otpRequest, Map<String, Object> model) throws IOException, TemplateException {
		EmailResponse response = new EmailResponse();
		MimeMessage message = sender.createMimeMessage();
		try {
			
			/**
			 * This method sent the otp to the email
			 * 
			 * **/
			MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED,
					StandardCharsets.UTF_8.name());
			
			  helper.setTo(otpRequest.getTo()); 
			  helper.setSubject("OTP to validate email given for registration"); 
			  helper.setFrom(otpRequest.getFrom());
			  helper.setText("OTP: " + otpRequest.getOtp() +"  "+ "Thanks for your interest in online account opening with our Bank");
			 
			  sender.send(message);
			 
			  response.setMessage("Email sent Successfully to: " + otpRequest.getTo());
			  response.setMessage("OTP: " + otpRequest.getOtp() +" Thanks for your interest in online account opening with our Bank");
			  response.setStatus(Boolean.TRUE);

		} catch (MessagingException e) {
			response.setMessage("Mail Sending failure : "+e.getMessage());
			response.setStatus(Boolean.FALSE);
		}

		return response;
	}	
	
	public EmailResponse sendEmailWithToken(EmailRequest tokenRequest, Map<String, Object> model) throws IOException, TemplateException {
		EmailResponse response = new EmailResponse();
		MimeMessage message = sender.createMimeMessage();
		try {
			/**
			 * This method sent the token or the application number in the email
			 * 
			 * */
			MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED,
					StandardCharsets.UTF_8.name());
			
			  helper.setTo(tokenRequest.getTo()); 
			  helper.setSubject("Acknowledgement for Online Registration "); 
			  helper.setFrom(tokenRequest.getFrom());
			  helper.setText("Acknowlegment No#: " + tokenRequest.getToken() +"  "+ 
					  		" Thanks your application has been submitted successfully.");
			 
			  sender.send(message);
			 
			  response.setMessage("Email sent Successfully to: " + tokenRequest.getTo());
			  response.setMessage("Acknowledgement No#: " + tokenRequest.getToken() + 
					  			  " Thanks your application has been submitted successfully.");
			  response.setStatus(Boolean.TRUE);

		} catch (MessagingException e) {
			response.setMessage("Mail Sending failure : "+e.getMessage());
			response.setStatus(Boolean.FALSE);
		}

		return response;
	}	

}
