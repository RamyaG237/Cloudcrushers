package com.digitalbanking.service;

import org.springframework.web.multipart.MultipartFile;

import com.digitalbanking.model.UploadFileResponse;


public interface FileUploadService {
	
	public UploadFileResponse getFileUploaded(MultipartFile file, String fileType, Long id) ;
	//public List<UploadFileResponse> getMultipleFilesUploaded(List<MultipartFile> files) ;

}
