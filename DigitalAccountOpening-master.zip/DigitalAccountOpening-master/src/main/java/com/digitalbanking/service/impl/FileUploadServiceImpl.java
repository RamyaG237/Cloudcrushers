package com.digitalbanking.service.impl;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.digitalbanking.exception.FileStorageException;
import com.digitalbanking.model.UploadFileResponse;
import com.digitalbanking.service.FileUploadService;
import com.digitalbanking.service.RegistrationService;
import com.digitalbanking.util.ConfigHelper;
import com.digitalbanking.util.FileNameGenerator;


@Service
public class FileUploadServiceImpl implements FileUploadService{
	
	private static final Logger log = LoggerFactory.getLogger(FileUploadServiceImpl.class);
	
	@Autowired
	ConfigHelper configHelper;
	
	@Autowired
	RegistrationService regService;
	
	/**
	 * Creates a folder, if it does not exists, to upload the files
	 */
    public void createFolder() {
		File theDir = new File(configHelper.getGetUploadedFolderPath());
		
        if (!theDir.exists()) {
            theDir.mkdirs();
            log.debug("Folder created : {} ", theDir);
        }else {
        	log.debug("Folder exists : {} ", theDir);
        }    
        
    }
    
    /**
     * Upload Single file 
     * @param id
     * @param file
     * @param fileType - this is hard coded value(Adhar) coming from UI
     * @return new name of the file as stored, the dowloadURi, size and content Type
     */
	
	public UploadFileResponse getFileUploaded(MultipartFile file, String fileType, Long id)  {
		
		createFolder();	
		String fileName = storeUploadedFile(file, fileType, id);
		log.debug("File Uploaded is : {} ", fileName);
		
		String fileDownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath()
											                .path("/downloadFile/")
											                .path(fileName)
											                .toUriString();
		
		return new UploadFileResponse(fileName, fileDownloadUri,file.getContentType(), file.getSize());
	}	 
	
	/**
	 * Internal method called to save the file and  get the target filename
	 * @param file
	 * @param fileType
	 * @param id
	 * @return targetFilename
	 */
	public String storeUploadedFile(MultipartFile file, String fileType, Long id)  {
		
		String orgfileName = StringUtils.cleanPath(file.getOriginalFilename());	
		log.debug("OriginalFileName is : {} ", orgfileName);	
		
		String token = regService.getToken(id);
		log.debug("TokenValue is : {} ", token);
		
		String targetFileName = FileNameGenerator.createFileName(token, fileType, orgfileName);
		log.debug("targetFileName is : {} ", targetFileName);
		
		try {
			Path targetLocation = (Paths.get(configHelper.getGetUploadedFolderPath())
							   			.toAbsolutePath().normalize())
										.resolve(targetFileName);		
			
			log.debug("Path for targetLocation is : {} ", targetLocation);
			
			Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);
			
		} catch (Exception e) {
			throw new FileStorageException("Unable to store File " + targetFileName);
		}

        return targetFileName;		
	}
	
	/**
	 * To upload Multiple File
	 * TODO
	 */
	/*public List<UploadFileResponse> getMultipleFilesUploaded(List<MultipartFile> files) {
		
		return  files.stream().<UploadFileResponse>map(file -> getFileUploaded(file))
							  .collect(Collectors.toList());
	}*/

}
