package com.digitalbanking.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Optional;

@SuppressWarnings("all")
public final class FileNameGenerator {

    private static final Logger log = LoggerFactory.getLogger(FileNameGenerator.class);
    private static final String FILE_DELIMETER = "_";
    private static final String EXT_DELIMETER = ".";

	public static String createFileName(String filePreffix,String fileType, String fileName){
		
		String fileExt = getFileExtension(fileName).get().toString();
		String newfileName = filePreffix + FILE_DELIMETER + fileType 
				 						 + EXT_DELIMETER + fileExt;
        
		log.debug("File Name Generated : {}",newfileName);	
        return newfileName;
    }
	
	private static Optional<String> getFileExtension(String filename) {
		
		return Optional.ofNullable(filename)
					   .filter(f -> f.contains("."))
					   .map(f -> f.substring(filename.lastIndexOf(".") + 1));

	}
	
}
