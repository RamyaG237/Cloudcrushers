package com.digitalbanking.util;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class ConfigHelper {
	
	public ConfigHelper() {
        super();
    }
	
	@Value("${getuploadedfolder.path}")
    private String getUploadedFolderPath;

	public String getGetUploadedFolderPath() {
		return getUploadedFolderPath;
	}

	public void setGetUploadedFolderPath(String getUploadedFolderPath) {
		this.getUploadedFolderPath = getUploadedFolderPath;
	}

}
