package com.digitalbanking.exception;

import java.time.LocalDateTime;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class CustomEntityResponseExceptionHandler extends ResponseEntityExceptionHandler {

	@ExceptionHandler(Exception.class)  
	public final ResponseEntity<Object> handleAllExceptions(Exception ex, WebRequest request)  
	{  
		//creating exception response structure  
		ExceptionResponse exceptionResponse= new ExceptionResponse(LocalDateTime.now(), 
							HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
							ex.getMessage(), request.getDescription(false));   
		   
		return new ResponseEntity<>(exceptionResponse, HttpStatus.INTERNAL_SERVER_ERROR);  
	}
	
	@ExceptionHandler(FileStorageException.class)  
	public final ResponseEntity<Object> handleFileStorageException(FileStorageException ex, 
							WebRequest request){  
		
		//creating exception response structure  
		ExceptionResponse exceptionResponse= new ExceptionResponse(LocalDateTime.now(), 
										HttpStatus.INSUFFICIENT_STORAGE.value(),
										HttpStatus.INSUFFICIENT_STORAGE.getReasonPhrase(),
										ex.getMessage(), request.getDescription(false));  
		 
		return new ResponseEntity<>(exceptionResponse, HttpStatus.INSUFFICIENT_STORAGE);  
	} 
	
	@ExceptionHandler(RecordNotFoundException.class)  
	public final ResponseEntity<Object> handleRecordNotFoundException(RecordNotFoundException ex, 
							WebRequest request){  
		
		//creating exception response structure  
		ExceptionResponse exceptionResponse= new ExceptionResponse(LocalDateTime.now(), 
										HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase(),
										ex.getMessage(), request.getDescription(false));  
		 
		return new ResponseEntity<>(exceptionResponse, HttpStatus.NOT_FOUND);  
	} 
	
}
